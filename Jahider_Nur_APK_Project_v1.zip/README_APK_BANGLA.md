# ☀️ Jahider Nur v1 — Mobile APK Guide (বাংলা)

## সত্য কথা আগে
Muse এর এই সার্ভারে Java / Android SDK নাই, জায়গাও মাত্র 7.5GB (APK বানাতে 10GB+ লাগে) — তাই এখান থেকে সরাসরি `.apk` ফাইল কম্পাইল করা যায়নি। **কিন্তু পুরো APK প্রজেক্ট Ready করে দিয়েছি** — নিচের যেকোনো একটা পথে ফ্রিতে APK বের হবে, কোডে আর কিছু করতে হবে না। সাথে সাথে ফোনে চালানোর জন্য Web App ভার্সনও আছে (Option 3)।

---

## ✅ Option 1 — GitHub দিয়ে ফ্রি APK (সবচেয়ে ভালো, ~20 মিনিট)
1. github.com এ ফ্রি অ্যাকাউন্ট খুলুন (ফোন দিয়েই হবে)
2. New Repository → নাম দিন `jahider-nur` → Create
3. এই ZIP এর সব ফাইল Upload করুন (**`.github` ফোল্ডারসহ** — PC থেকে upload করা সহজ)
4. Repository এর **Actions** ট্যাবে যান → "Build Jahider Nur APK" → **Run workflow**
5. 15-20 মিনিট পর শেষ হলে নিচে **Jahider_Nur_v1_APK** নামে Artifact পাবেন → Download → ভিতরে `.apk` ফাইল
6. APK টা ফোনে পাঠিয়ে Install করুন (Unknown Source চাইলে Allow দিন)

## ✅ Option 2 — Google Colab দিয়ে
1. colab.research.google.com → New Notebook
2. এই ফোল্ডার Upload করে পরপর চালান:
```
!pip install buildozer cython==0.29.36
!sudo apt-get install -y openjdk-17-jdk autoconf libtool pkg-config zlib1g-dev libffi-dev libssl-dev
!buildozer android debug
```
3. `bin/` ফোল্ডারে APK তৈরি হবে → Download করে ফোনে Install করুন

## ✅ Option 3 — এখনই ফোনে Install (APK ছাড়া, ১ মিনিটে)
`web_app/index.html` ফাইলটা ফোনে পাঠান → Chrome দিয়ে খুলুন → Chrome মেনু (⋮) → **"Add to Home screen / Install app"**
→ ফোনের হোম স্ক্রিনে **Jahider Nur** আইকন বসে যাবে, অ্যাপের মতোই খুলবে, Account খোলা, Devices, Map, Chat, News — সব চলবে, ডাটা ফোনেই থাকবে।

## অ্যাপে যা যা আছে (v1, Account ছাড়া)
- 🔐 Register / Login — নিজের Device ID (NUR-XXXXXX)
- 🗺️ Offline Map — নিজের পজিশন, মুভমেন্ট, 500m সার্কেল
- 📡 Devices — কয়টা ডিভাইস, কে Direct, কে Relay (কয় hop, কোন রুটে)
- 💬 Chat • 🎤 Voice • 📞 Call (Simulation) • 📰 News Portal
- 💾 Local Database — ফোনের নিজের স্টোরেজে

## ফাইল
- `main.py` — Kivy Mobile App (আসল APK এর কোড)
- `buildozer.spec` — APK সেটিংস (নাম: Jahider Nur, v1.0, Package: org.jahidernur.jahidernur)
- `.github/workflows/build-apk.yml` — GitHub অটো APK বিল্ড
- `web_app/index.html` — এখনই চালানোর Web App ভার্সন
